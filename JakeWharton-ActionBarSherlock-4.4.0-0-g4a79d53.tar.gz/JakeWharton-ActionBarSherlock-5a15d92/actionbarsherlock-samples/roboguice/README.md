ActionBarSherlock Sample: RoboGuice
===================================

See [actionbarsherlock.com/samples.html][1] for information on the sample
contained in this folder.

This sample uses the [roboguice-sherlock][2] plugin from Roberto Tyley.







 [1]: http://actionbarsherlock.com/samples.html
 [2]: https://github.com/rtyley/roboguice-sherlock
